#ifndef _TINYFLASH_H_
#define _TINYFLASH_H_

#include "application.h"

// For IS25LQ080
// #define CHIP_BYTES       1L * 1024L * 1024L
// #define MAN_ID 0x9D
//#define MAN_ID2 0x7F
// #define DEV_ID 0x13
//#define DEV_ID2 0x44

// // W25Q80BV
// #ifndef CHIP_BYTES
// 	#define CHIP_BYTES       1L * 1024L * 1024L
// #endif

// #ifndef MAN_ID
// #define MAN_ID 0xEF
// #endif
// #ifndef DEV_ID
// #define DEV_ID 0x13
// #endif

// Micron MT29F1G01ABAFDSF, Added by PJB 2017-12-20
#ifndef CHIP_BYTES
	#define CHIP_BYTES       64L * 2176L // 64 pages * 2176 bytes
#endif
#ifndef MAN_ID
#define MAN_ID 0x2C
#endif
#ifndef DEV_ID
#define DEV_ID 0x14
#endif
//

#define PAGE_SIZE 2176 // was 256, PJB 2017-12-20

#define CMD_PAGEPROG     0x02 // same but this is a whole sequence of commands per pg 29 of MT29F1G01ABAFDSF datasheet
#define CMD_READDATA     0x03 // same but looks like 0x13 for NAND PAGE READ
#define CMD_READFASTDATA 0x0B // same but called fast read from cache for NAND
#define CMD_WRITEDISABLE 0x04 // same
#define CMD_READSTAT1    0x05 // can't find for NAND, no change for NOR
#define CMD_WRITEENABLE  0x06 // same
#define CMD_SECTORERASE  0xD8 // PJB; was 0x20
#define CMD_CHIPERASE    0x60 // can't find for NAND, 0xC4 is die erase on NOR
#define CMD_ID           0x9F // PJB; was 0x90
#define CMD_WRITESTAT	 0x01 // can't find for NAND, no change for NOR

#define STAT_BUSY        0x01
#define STAT_WRTEN       0x02




class Adafruit_TinyFlash {
 public:

	Adafruit_TinyFlash();

  uint32_t          begin(uint8_t flashcs);
  boolean           beginRead(uint32_t addr),
	  // Write max 256 bytes.
                    writePage(uint32_t addr, uint8_t *data, uint32_t length),
                    eraseChip(void),
                    eraseSector(uint32_t addr);
  boolean           beginFastRead(uint32_t addr);
  // Write any amount of data
  //boolean writeData(const uint8_t* data, uint32_t address, uint32_t length);
  uint8_t           readNextByte(void);
  void              endRead(void);
  uint8_t ReadStatusRegister(void);
    boolean WriteStatusRegister(uint8_t data);
	boolean readData(uint8_t* data, uint32_t address, uint32_t length);

 private:
  boolean           waitForReady(uint32_t timeout = 100L),
                    writeEnable(void);
  void              writeDisable(void),
                    cmd(uint8_t c);

  volatile uint8_t cs_port;
};

#endif // _TINYFLASH_H_
